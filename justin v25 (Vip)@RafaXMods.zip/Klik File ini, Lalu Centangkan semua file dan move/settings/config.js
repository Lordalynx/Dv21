const fs = require('fs')

const config = {
    owner: "-",
    botNumber: "-",
    setPair: "JUSTIN25",
    thumbUrl: "https://files.catbox.moe/bvkgr4.jpg",
    session: "sessions",
    status: {
        public: true,
        terminal: true,
        reactsw: false
    },
    message: {
        owner: "no, this is for owners only",
        group: "this is for groups only",
        admin: "this command is for admin only",
        private: "this is specifically for private chat"
    },
    settings: {
        title: "JustinOfficialV25",
        packname: 'JustinOfficialV25',
        description: "this script was created by JustinXSatanic",
        author: 'https://www.kyuurzy.tech',
        footer: "JustinXSatanic - 2025`"
    },
    newsletter: {
        name: "JustinOfficial",
        id: "120363373003239606@newsletter"
    },
    socialMedia: {
        YouTube: "https://youtube.com/@justinofficial-id",
        GitHub: "https://github.com/kiuur",
        Telegram: "https://t.me/justinoffc",
        ChannelWA: "https://whatsapp.com/channel/0029VaxxUio545v2bL3FE91g"
    }
}

module.exports = config;

let file = require.resolve(__filename)
require('fs').watchFile(file, () => {
  require('fs').unwatchFile(file)
  console.log('\x1b[0;32m'+__filename+' \x1b[1;32mupdated!\x1b[0m')
  delete require.cache[file]
  require(file)
})
